#ifndef TIMER_H
#define TIMER_H

#include "simulator.h"

void timer_tick(SimState *state);

#endif // TIMER_H
