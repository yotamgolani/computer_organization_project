#ifndef MONITOR_H
#define MONITOR_H

#include "simulator.h"

void monitor_cmd_write(SimState *state);

#endif // MONITOR_H
