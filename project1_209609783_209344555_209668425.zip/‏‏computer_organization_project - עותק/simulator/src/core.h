#ifndef CORE_H
#define CORE_H

#include "simulator.h"
#include <stdio.h>

bool core_step(SimState *state);

#endif // CORE_H
